/// <reference types="vite/client" />
/// <reference types="@emotion/react/types/css-prop" />

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
