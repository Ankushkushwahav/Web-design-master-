export enum ShapeType {
  RECT = 'rect',
  CIRCLE = 'circle',
  POLYGON = 'polygon',
  STAR = 'star',
  ARROW = 'arrow',
}
