export const DEFAULT_IMG_QUERY = 'design';
export const UNSPLASH_URL = 'https://unsplash.com/';

export const MAX_IMAGE_WIDTH = 400;
export const MAX_IMAGE_HEIGHT = 700;
