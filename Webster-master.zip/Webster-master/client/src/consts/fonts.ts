export const FONT_VARIANTS_TO_LOAD = ['400', '400italic', '700', '700italic'];
export const GOOGLE_FONTS_API_URL = 'https://www.googleapis.com/';
export const GOOGLE_FONTS_STYLESHEETS_API_URL = 'https://fonts.googleapis.com/';
