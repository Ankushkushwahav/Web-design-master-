export class SignInResponseDto {
  accessToken: string;
}
