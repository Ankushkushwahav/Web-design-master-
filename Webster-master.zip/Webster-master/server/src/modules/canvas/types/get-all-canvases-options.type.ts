export type GetAllCanvasesOptionsType = {
  take?: number;
  skip?: number;
  cursor?: { id: string };
};
