export type GetAllCanvasesWhereType = {
  name?: string;
  description?: string;
  authorId?: string;
};
