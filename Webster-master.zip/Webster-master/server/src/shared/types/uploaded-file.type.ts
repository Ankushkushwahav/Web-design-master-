export type UploadedFileType = {
  path: string;
  originalName: string;
  mimeType: string;
};
