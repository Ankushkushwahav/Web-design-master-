export type HttpUserPayload = {
  id: string;
};
