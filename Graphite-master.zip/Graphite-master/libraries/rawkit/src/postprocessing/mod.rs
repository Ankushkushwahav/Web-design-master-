pub mod convert_to_rgb;
pub mod gamma_correction;
pub mod record_histogram;
pub mod transform;
