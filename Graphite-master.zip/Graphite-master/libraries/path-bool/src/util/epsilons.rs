#[derive(Clone, Copy, Debug)]
pub struct Epsilons {
	pub point: f64,
	pub linear: f64,
	pub param: f64,
}
