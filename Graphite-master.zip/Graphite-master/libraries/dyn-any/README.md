# DynAny Trait


A `Any`-like trait and derive macros for non `'static` lifetimes.
