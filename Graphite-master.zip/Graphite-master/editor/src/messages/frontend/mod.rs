mod frontend_message;

pub mod utility_types;

#[doc(inline)]
pub use frontend_message::{FrontendMessage, FrontendMessageDiscriminant};
